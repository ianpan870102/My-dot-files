Consolas-High-Line
==================
Version of widely used `Consolas` font family with increased line-height.

I love `Consolas` for its state-of-the-art bold and italic and excellent hinting. But I hate how it looks in Eclipse IDE, I mean line-height: lines appear so close to each other, so hard to read, ughhh... So after spending a few hours searching for a good font family and disappointing in what's purposed, I opened original `Consolas` in font editor and increased line-height to make it look nicer and much more readable in Eclipse.

**This is the Original `Consolas`:**

![consolas-original](https://user-images.githubusercontent.com/7059765/27511926-ca8148d6-5939-11e7-9636-6dbf917f2d42.PNG)

**And that is `ConsolasHigh` with increased line-height:**

![consolas-high-line](https://user-images.githubusercontent.com/7059765/27511925-ca4ccf0c-5939-11e7-865b-1628771bb4fc.PNG)

